See EXAMPLES and BACKENDS files in the docs/ folder.

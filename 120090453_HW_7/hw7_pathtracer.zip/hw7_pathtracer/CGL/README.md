# CGL Library 
Designed to build simple graphics applications for CS 184/284A.

The library provides basic vector operations, takes care of OpenGL context creation, window event handling, and an on-screen text display interface using freetype. The library is designed to provide a simple interface for building graphics applications and is used in CS 184/284A assignments.

Originally written by CMU462 Fall 2015: 
Kayvon Fatahalian, Keenan Crane,
Sky Gao, Bryce Summers, Michael Choquette
 for the bulk of the code.

Heavily modified for CS 184/284A Spring 2019.

